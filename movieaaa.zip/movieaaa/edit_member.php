﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php
$currentMember = getCurrentMember($_GET["userid"]);
if(isset($_POST["submit"])){
  if($_POST["userID"] == ""){
    saveMember($_POST["Email"],$_POST["Password"],$_POST["FirstName"],$_POST["LastName"],$_FILES["UserPicture"]["name"]);
  }else{
    editMember($_POST["userID"],$_POST["Email"],$_POST["Password"],$_POST["FirstName"],$_POST["LastName"],$_FILES["UserPicture"]["name"]);
  }
}
if($_GET["userid"] == ""){
  $txtHead = "Add User";
}else{
  $txtHead = "Edit User";
}
?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-5 animate-box" data-animate-effect="fadeInLeft">
            <?php if($currentMember["UserPicture"] != ""){ ?>
              <img class="img-responsive" src="images/user/<?php echo $currentMember["UserPicture"];?>" alt="" id="blah">
            <?php }else{ ?>
              <img class="img-responsive" src="images/profile_ico.png" alt="" id="blah">
            <?php }?>
          </div>
          <div class="col-md-7 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading"><?php echo $txtHead;?></h2>

            <form name="register_form" action="" method="post" >
              <input type="hidden" class="form-control" name="userID" value="<?php echo $currentMember["userID"];?>">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" name="Email" placeholder="Email" required value="<?php echo $currentMember["Email"];?>">
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" name="Password" placeholder="Password" required value="<?php echo $currentMember["Password"];?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Name</label>
                    <input type="text" class="form-control" name="FirstName" placeholder="firstname" required value="<?php echo $currentMember["FirstName"];?>">
                  </div>
                  <div class="form-group">
                    <label>Surname</label>
                    <input type="text" class="form-control" name="LastName" placeholder="lastname" required value="<?php echo $currentMember["LastName"];?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Profile Picture</label>
                    <input type="file" class="form-control" name="UserPicture" id="UserPicture" placeholder="Profile Picture" >
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12" style="text-align: right;">
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary btn-outline" value="Submit">
                  </div>
                </div>
              </div>


            </form>

          </div>
        </div>
        
      </div>
      

    </div>
  </div>


</body>
</html>

