<?php
error_reporting(0);

//connect to database
$con = mysqli_connect("localhost","adminMovie","admin1234","movieaaa");
$con->set_charset("utf8");
date_default_timezone_set("Asia/Bangkok");

function checkLogin($Email,$Password){
	$data = array();
	$datalog = array();
	global $con;
	$repass = hash('sha3-256', $Password);
	$sql = "select * from user where Email = '".$Email."' and Password='".$repass."' ";
	$res = mysqli_query($con,$sql);
	
	while($row = mysqli_fetch_array($res)) {
		$data['userID'] = $row['userID'];
		$data['Role'] = $row['Role'];
	}
	if (!empty($data)) {
		session_start();
		$id = $data['id'];
		$_SESSION['id'] = $data['userID'];
		$_SESSION['role'] = $data['Role'];
		echo ("<script language='JavaScript'>
			window.location.href='index.php';
			</script>");
	}else{
		echo "<script type='text/javascript'>alert('Incorrect Email or Password!');</script>";
	}
	
	mysqli_close($con);

}

function formatDateFull($date){
	if($date=="0000-00-00"){
		return "";
	}
	if($date=="")
		return $date;
	$raw_date = explode("-", $date);
	return  $raw_date[2] . "/" . $raw_date[1] . "/" . $raw_date[0];
}

function formatDateFullConvertYear($date){
	if($date=="0000-00-00"){
		return "";
	}
	if($date=="")
		return $date;
	$raw_date = explode("-", $date);
	$raw_date[0] = $raw_date[0]+543;
	return  $raw_date[2] . "/" . $raw_date[1] . "/" . $raw_date[0];
}


function logout(){
	session_start();
	session_unset();
	session_destroy();
	echo ("<script language='JavaScript'>
		window.location.href='index.php';
		</script>");
	exit();
}

function saveRegister($Email, $Password, $FirstName, $LastName, $UserPicture) {
    global $con;

    $repass = hash('sha3-256', $Password);
    $pictureFilename = '';

    if($UserPicture != null && $_FILES["UserPicture"]["error"] == UPLOAD_ERR_OK) {
        $pictureFilename = $_FILES["UserPicture"]["name"];
        move_uploaded_file($_FILES["UserPicture"]["tmp_name"], "images/user/" . $pictureFilename);
    }

    $query = "CALL RegisterUser('$FirstName', '$LastName', '$Email', '$repass', '$pictureFilename')";
    $res = mysqli_query($con, $query);

    if($res) {
        echo ("<script language='JavaScript'>
            alert('Registered');
            window.location.href='login.php';
        </script>");
    } else {
        echo ("<script language='JavaScript'>
            alert('Registration failed. Please try again.');
            window.location.href='register.php'; 
        </script>");
    }

    mysqli_close($con);
}

function getCurrentUser($userID){

	global $con;

	$res = mysqli_query($con,"SELECT * FROM user WHERE userID = '".$userID."'");
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}

function editProfile($userID, $Email, $Password, $FirstName, $LastName, $UserPicture) {
    global $con;

    $repass = hash('sha3-256', $Password);
    $pictureFilename = $_FILES["UserPicture"]["name"];

    if($UserPicture != null && move_uploaded_file($_FILES["UserPicture"]["tmp_name"], "images/user/".$pictureFilename)) {
        $sql = "CALL UpdateUserProfile('$userID', '$FirstName', '$LastName', '$Email', '$repass', '$pictureFilename')";
    } else {
        $sql = "CALL UpdateUserProfile('$userID', '$FirstName', '$LastName', '$Email', '$repass', NULL)";
    }

    mysqli_query($con, $sql);
    if(mysqli_error($con)) {
        die("Error updating record: " . mysqli_error($con));
    }

    mysqli_close($con);

    echo ("<script language='JavaScript'>
        alert('Edited');
        window.location.href='profile.php';
    </script>");
}


function getUser($id){

	global $con;

	$res = mysqli_query($con,"SELECT * FROM users WHERE id = '".$id."'");
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}

function saveAdmin($Email,$Password,$FirstName,$LastName,$UserPicture){
	
	global $con;

	$repass = hash('sha3-256', $Password);

	if($UserPicture != null ){
		if(move_uploaded_file($_FILES["UserPicture"]["tmp_name"],"images/user/".$_FILES["UserPicture"]["name"]))
		{
			$sql = "INSERT INTO user (FirstName, LastName, Email, Password, UserPicture, Role) VALUES('".$FirstName."','".$LastName."','".$Email."','".$repass."','".$_FILES["UserPicture"]["name"]."','1')";
		}
	}else{
		$sql = "INSERT INTO user (FirstName, LastName, Email, Password, Role) VALUES('".$FirstName."','".$LastName."','".$Email."','".$repass."','1')";
	}
	mysqli_query($con,$sql);
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Added');
		window.location.href='manage_admin.php';
		</script>"); 
	
}

function editAdmin($userID,$Email,$Password,$FirstName,$LastName,$UserPicture){
	
	global $con;
	$repass = hash('sha3-256', $Password);

	if($UserPicture != null ){
		if(move_uploaded_file($_FILES["UserPicture"]["tmp_name"],"images/user/".$_FILES["UserPicture"]["name"]))
		{
			$sql="UPDATE user SET FirstName='".$FirstName."',LastName='".$LastName."',Email='".$Email."',Password='".$repass."',UserPicture='".$_FILES["UserPicture"]["name"]."',Role='1' WHERE userID = '".$userID."'";
		}
	}else{
		$sql="UPDATE user SET FirstName='".$FirstName."',LastName='".$LastName."',Email='".$Email."',Password='".$repass."',Role='1' WHERE userID = '".$userID."'";

	}
	mysqli_query($con,$sql);
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Added');
		window.location.href='manage_admin.php';
		</script>"); 
	
}

function deleteAdmin($userID){
	global $con;

	mysqli_query($con,"DELETE FROM user WHERE userID='".$userID."'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Deleted');
		window.location.href='manage_admin.php';
		</script>"); 

}

function getAllAdmin(){
	global $con;

	$sql = "SELECT * FROM user WHERE Role='1' ORDER BY userID DESC";
	$res = mysqli_query($con,$sql);

	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'userID' => $row['userID'],
			'FirstName' => $row['FirstName'],
			'LastName' => $row['LastName'],
			'Email' => $row['Email'],
			'Password' => $row['Password'],
			'UserPicture' => $row['UserPicture'],
			'Role' => $row['Role']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}

function getCurrentAdmin($userID){

	global $con;

	$res = mysqli_query($con,"SELECT * FROM user WHERE userID = '".$userID."'");
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}

function saveMember($Email,$Password,$FirstName,$LastName,$UserPicture){
	
	global $con;
	$repass = hash('sha3-256', $Password);

	if($UserPicture != null ){
		if(move_uploaded_file($_FILES["UserPicture"]["tmp_name"],"images/user/".$_FILES["UserPicture"]["name"]))
		{
			$sql = "INSERT INTO user (FirstName, LastName, Email, Password, UserPicture, Role) VALUES('".$FirstName."','".$LastName."','".$Email."','".$repass."','".$_FILES["UserPicture"]["name"]."','2')";
		}
	}else{
		$sql = "INSERT INTO user (FirstName, LastName, Email, Password, Role) VALUES('".$FirstName."','".$LastName."','".$Email."','".$repass."','2')";
	}
	mysqli_query($con,$sql);
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Added');
		window.location.href='manage_member.php';
		</script>"); 
	
}

function editMember($userID,$Email,$Password,$FirstName,$LastName,$UserPicture){
	
	global $con;
	$repass = hash('sha3-256', $Password);

	if($UserPicture != null ){
		if(move_uploaded_file($_FILES["UserPicture"]["tmp_name"],"images/user/".$_FILES["UserPicture"]["name"]))
		{
			$sql="UPDATE user SET FirstName='".$FirstName."',LastName='".$LastName."',Email='".$Email."',Password='".$repass."',UserPicture='".$_FILES["UserPicture"]["name"]."',Role='2' WHERE userID = '".$userID."'";
		}
	}else{
		$sql="UPDATE user SET FirstName='".$FirstName."',LastName='".$LastName."',Email='".$Email."',Password='".$repass."',Role='2' WHERE userID = '".$userID."'";

	}
	mysqli_query($con,$sql);
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Edited');
		window.location.href='manage_member.php';
		</script>"); 
	
}

function deleteMember($userID){
	global $con;

	mysqli_query($con,"DELETE FROM user WHERE userID='".$userID."'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Deleted');
		window.location.href='manage_member.php';
		</script>"); 

}

function getAllMember(){
	global $con;

	$sql = "SELECT * FROM user WHERE role='2' ORDER BY userID DESC";
	$res = mysqli_query($con,$sql);

	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'userID' => $row['userID'],
			'FirstName' => $row['FirstName'],
			'LastName' => $row['LastName'],
			'Email' => $row['Email'],
			'Password' => $row['Password'],
			'UserPicture' => $row['UserPicture'],
			'Role' => $row['Role']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}

function getCurrentMember($userID){

	global $con;
	$sql = "SELECT * FROM user WHERE userID = '".$userID."'";
	$res = mysqli_query($con,$sql);
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}

function saveCategory($GenreType){
	
	
	global $con;

	$sql = "INSERT INTO genre (GenreType) VALUES('".$GenreType."')";
	mysqli_query($con,$sql);
	
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Added');
		window.location.href='manage_category.php';
		</script>"); 
	
}

function editCategory($GenreID,$GenreType){

	global $con;

	$sql="UPDATE genre SET GenreType='".$GenreType."' WHERE GenreID = '".$GenreID."'";
	mysqli_query($con,$sql);
	
	mysqli_close($con);

	echo ("<script language='JavaScript'>
		alert('Edited');
		window.location.href='manage_category.php';
		</script>"); 
	
}

function deleteCategory($GenreID){
	global $con;

	mysqli_query($con,"DELETE FROM genre WHERE GenreID='".$GenreID."'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Deleted');
		window.location.href='manage_category.php';
		</script>"); 

}

function getAllCategory(){
	global $con;

	$sql = "SELECT * FROM genre ORDER BY GenreID DESC";
	$res = mysqli_query($con,$sql);

	$data = array();

	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'GenreID' => $row['GenreID'],
			'GenreType' => $row['GenreType']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}

function getCurrentCategory($GenreID){

	global $con;

	$res = mysqli_query($con,"SELECT * FROM genre WHERE GenreID = '".$GenreID."'");
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}

function saveMovie($GenreID,$MovieName,$MovieLength,$ReleaseDate,$MovieDesc,$MoviePoster,$MovieFile){
	
	global $con;

	$arrDate1 = explode("/", $ReleaseDate);
	$convert_ReleaseDate = $arrDate1[2].'-'.$arrDate1[1].'-'.$arrDate1[0];

	if($MoviePoster != null && $MovieFile != null){
		if(move_uploaded_file($_FILES["MoviePoster"]["tmp_name"],"images/poster/".$_FILES["MoviePoster"]["name"]) && move_uploaded_file($_FILES["MovieFile"]["tmp_name"],"images/movie/".$_FILES["MovieFile"]["name"]))
		{
			$sql = "INSERT INTO movie (MovieName, GenreID, MoviePoster, MovieDesc, MovieLength, ReleaseDate, TotalViews, MovieFile) VALUES('".$MovieName."','".$GenreID."','".$_FILES["MoviePoster"]["name"]."','".$MovieDesc."','".$MovieLength."','".$convert_ReleaseDate."','0','".$_FILES["MovieFile"]["name"]."')";
		}
	}
	mysqli_query($con,$sql);
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Added');
		window.location.href='manage_movie.php';
		</script>"); 
	
}

function editMovie($MovieID,$GenreID,$MovieName,$MovieLength,$ReleaseDate,$MovieDesc,$MoviePoster,$MovieFile){
	
	global $con;

	$arrDate1 = explode("/", $ReleaseDate);
	$convert_ReleaseDate = $arrDate1[2].'-'.$arrDate1[1].'-'.$arrDate1[0];

	if($MoviePoster != null && $MovieFile != null){
		if(move_uploaded_file($_FILES["MoviePoster"]["tmp_name"],"images/poster/".$_FILES["MoviePoster"]["name"]) && move_uploaded_file($_FILES["MovieFile"]["tmp_name"],"images/movie/".$_FILES["MovieFile"]["name"]))
		{
			$sql="UPDATE movie SET MovieName='".$MovieName."',GenreID='".$GenreID."',MoviePoster='".$_FILES["MoviePoster"]["name"]."',MovieDesc='".$MovieDesc."',MovieLength='".$MovieLength."',ReleaseDate='".$convert_ReleaseDate."',MovieFile='".$_FILES["MovieFile"]["name"]."' WHERE MovieID = '".$MovieID."'";
		}
	}else if($MoviePoster != null && $MovieFile == null){
		if(move_uploaded_file($_FILES["MoviePoster"]["tmp_name"],"images/poster/".$_FILES["MoviePoster"]["name"]))
		{
			$sql="UPDATE movie SET MovieName='".$MovieName."',GenreID='".$GenreID."',MoviePoster='".$_FILES["MoviePoster"]["name"]."',MovieDesc='".$MovieDesc."',MovieLength='".$MovieLength."',ReleaseDate='".$convert_ReleaseDate."' WHERE MovieID = '".$MovieID."'";
		}
	}else if($MoviePoster == null && $MovieFile != null){
		if(move_uploaded_file($_FILES["MovieFile"]["tmp_name"],"images/movie/".$_FILES["MovieFile"]["name"]))
		{
			$sql="UPDATE movie SET MovieName='".$MovieName."',GenreID='".$GenreID."',MovieDesc='".$MovieDesc."',MovieLength='".$MovieLength."',ReleaseDate='".$convert_ReleaseDate."',MovieFile='".$_FILES["MovieFile"]["name"]."' WHERE MovieID = '".$MovieID."'";
		}
	}else{
		$sql="UPDATE movie SET MovieName='".$MovieName."',GenreID='".$GenreID."',MovieDesc='".$MovieDesc."',MovieLength='".$MovieLength."',ReleaseDate='".$convert_ReleaseDate."' WHERE MovieID = '".$MovieID."'";

	}
	mysqli_query($con,$sql);
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Edited');
		window.location.href='manage_movie.php';
		</script>"); 
	
}

function deleteMovie($MovieID){
	global $con;

	mysqli_query($con,"DELETE FROM movie WHERE MovieID='".$MovieID."'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Delete');
		window.location.href='manage_movie.php';
		</script>"); 

}

function getAllMovie(){
	global $con;

	$sql = "SELECT * FROM movie m LEFT JOIN genre g ON m.GenreID = g.GenreID ORDER BY m.MovieID DESC";
	$res = mysqli_query($con,$sql);
	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'MovieID' => $row['MovieID'],
			'GenreType' => $row['GenreType'],
			'MovieName' => $row['MovieName'],
			'GenreID' => $row['GenreID'],
			'MoviePoster' => $row['MoviePoster'],
			'MovieDesc' => $row['MovieDesc'],
			'MovieLength' => $row['MovieLength'],
			'ReleaseDate' => $row['ReleaseDate'],
			'MovieFile' => $row['MovieFile'],
			'TotalViews' => $row['TotalViews']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}



function getAllMovieTopView(){
	global $con;

	$sql = "SELECT * FROM movie m LEFT JOIN genre g ON m.GenreID = g.GenreID ORDER BY m.TotalViews DESC LIMIT 0, 4";
	$res = mysqli_query($con,$sql);

	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'MovieID' => $row['MovieID'],
			'GenreType' => $row['GenreType'],
			'MovieName' => $row['MovieName'],
			'GenreID' => $row['GenreID'],
			'MoviePoster' => $row['MoviePoster'],
			'MovieDesc' => $row['MovieDesc'],
			'MovieLength' => $row['MovieLength'],
			'ReleaseDate' => $row['ReleaseDate'],
			'MovieFile' => $row['MovieFile'],
			'TotalViews' => $row['TotalViews']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}
function getNewMovieTopView(){
	global $con;

	$sql = "SELECT * FROM movie m LEFT JOIN genre g ON m.GenreID = g.GenreID ORDER BY m.MovieID DESC LIMIT 0, 4";
	$res = mysqli_query($con,$sql);

	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'MovieID' => $row['MovieID'],
			'GenreType' => $row['GenreType'],
			'MovieName' => $row['MovieName'],
			'GenreID' => $row['GenreID'],
			'MoviePoster' => $row['MoviePoster'],
			'MovieDesc' => $row['MovieDesc'],
			'MovieLength' => $row['MovieLength'],
			'ReleaseDate' => $row['ReleaseDate'],
			'MovieFile' => $row['MovieFile'],
			'TotalViews' => $row['TotalViews']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}
function getAllMovieInCategory($GenreID){
	global $con;

	$sql = "SELECT * FROM movie m LEFT JOIN genre g ON m.GenreID = g.GenreID WHERE m.GenreID = '".$GenreID."' ORDER BY m.TotalViews DESC";
	$res = mysqli_query($con,$sql);
	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'MovieID' => $row['MovieID'],
			'GenreType' => $row['GenreType'],
			'MovieName' => $row['MovieName'],
			'GenreID' => $row['GenreID'],
			'MoviePoster' => $row['MoviePoster'],
			'MovieDesc' => $row['MovieDesc'],
			'MovieLength' => $row['MovieLength'],
			'ReleaseDate' => $row['ReleaseDate'],
			'MovieFile' => $row['MovieFile'],
			'TotalViews' => $row['TotalViews']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}

function getAllMovieInCategoryLimit($GenreID){
	global $con;

	$sql = "SELECT * FROM movie m LEFT JOIN genre g ON m.GenreID = g.GenreID WHERE m.GenreID = '".$GenreID."' ORDER BY m.TotalViews DESC LIMIT 0, 8";
	$res = mysqli_query($con,$sql);
	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'MovieID' => $row['MovieID'],
			'GenreType' => $row['GenreType'],
			'MovieName' => $row['MovieName'],
			'GenreID' => $row['GenreID'],
			'MoviePoster' => $row['MoviePoster'],
			'MovieDesc' => $row['MovieDesc'],
			'MovieLength' => $row['MovieLength'],
			'ReleaseDate' => $row['ReleaseDate'],
			'MovieFile' => $row['MovieFile'],
			'TotalViews' => $row['TotalViews']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}
function getCurrentMovie($MovieID){

	global $con;
	$sql = "SELECT * FROM movie m LEFT JOIN genre g ON m.GenreID = g.GenreID WHERE m.MovieID = '".$MovieID."'";
	$res = mysqli_query($con,$sql);
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}


function saveHistory($MovieID,$UserID,$MovieFile){
	
	global $con;
	$yThai = date("Y")+543;
	$dateNow = $yThai.date("-m-d HH:mm:ss");
	$data = array();
	$data2 = array();

	$sql = "select HistoryID from usermoviehistory where UserID = '".$UserID."' and MovieID='".$MovieID."' ";
	$res = mysqli_query($con,$sql);
	
	while($row = mysqli_fetch_array($res)) {
		$data['HistoryID'] = $row['HistoryID'];
	}

	$sqlView = "select TotalViews from movie where MovieID='".$MovieID."' ";
	$res2 = mysqli_query($con,$sqlView);
	
	while($row2 = mysqli_fetch_array($res2)) {
		$data2['TotalViews'] = $row2['TotalViews'];
	}
	$numView = $data2['TotalViews'] + 1;
	$sql_view = "UPDATE movie SET TotalViews ='".$numView."' WHERE MovieID = '".$MovieID."'";
	mysqli_query($con,$sql_view);
	if (empty($data)) {
		$sql_update = "INSERT INTO usermoviehistory (UserID, MovieID, ViewDate) VALUES('".$UserID."','".$MovieID."',NOW())";
		mysqli_query($con,$sql_update);
	}else{

		$sql_update = "UPDATE usermoviehistory SET ViewDate=CURRENT_TIMESTAMP WHERE UserID = '".$UserID."' and MovieID='".$MovieID."'";
		mysqli_query($con,$sql_update);
	}
	

	mysqli_close($con);
	echo ("<script language='JavaScript'>
		window.location.href='full_screen.php?files=$MovieFile';
		</script>"); 
	
}

function savePayment($userID,$CardHolderName,$CreditCardnum,$expiryDate,$CVV,$CardType){
	
	global $con;

	$yThai = date("Y")+543;
	$dateNow = $yThai.date("-m-d");

	$arrDate1 = explode("/", $expiryDate);
	$convert_expiryDate = $arrDate1[2].'-'.$arrDate1[1].'-'.$arrDate1[0];

	$sql = "INSERT INTO payment (PaymentDate, userID, CardHolderName, CreditCardnum, expiryDate, CVV, CardType) VALUES('".$dateNow."','".$userID."','".$CardHolderName."','".$CreditCardnum."','".$convert_expiryDate."','".$CVV."','".$CardType."')";
	//print_r($sql);
	//die();
	mysqli_query($con,$sql);
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Saved');
		window.location.href='manage_payment.php';
		</script>"); 
	
}

function editPayment($PaymentID,$userID,$CardHolderName,$CreditCardnum,$expiryDate,$CVV,$CardType){
	
	global $con;

	$yThai = date("Y")+543;
	$dateNow = $yThai.date("-m-d");

	$arrDate1 = explode("/", $expiryDate);
	$convert_expiryDate = $arrDate1[2].'-'.$arrDate1[1].'-'.$arrDate1[0];

	$sql="UPDATE payment SET PaymentDate='".$dateNow."',userID='".$userID."',CardHolderName='".$CardHolderName."',CreditCardnum='".$CreditCardnum."',expiryDate='".$convert_expiryDate."',CVV='".$CVV."',CardType='".$CardType."' WHERE PaymentID = '".$PaymentID."'";
	mysqli_query($con,$sql);
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Edited');
		window.location.href='manage_payment.php';
		</script>"); 
	
}

function deletePayment($PaymentID){
	global $con;

	mysqli_query($con,"DELETE FROM payment WHERE PaymentID='".$PaymentID."'");
	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('DONE!');
		window.location.href='manage_payment.php';
		</script>"); 

}

function getAllPayment($userID){
	global $con;

	$sql = "SELECT * FROM payment WHERE userID='".$userID."' ORDER BY PaymentID DESC";
	$res = mysqli_query($con,$sql);

	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'PaymentID' => $row['PaymentID'],
			'PaymentDate' => $row['PaymentDate'],
			'userID' => $row['userID'],
			'CardHolderName' => $row['CardHolderName'],
			'CreditCardnum' => $row['CreditCardnum'],
			'expiryDate' => $row['expiryDate'],
			'CVV' => $row['CVV'],
			'CardType' => $row['CardType']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}

function getCurrentPayment($PaymentID){

	global $con;

	$res = mysqli_query($con,"SELECT * FROM payment WHERE PaymentID = '".$PaymentID."'");
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}

function confirmPayment($userID,$PaymentID,$StartDate,$DueDate,$Price){
	
	global $con;

	$data = array();

	$sql = "select userID from subscription where userID = '".$userID."' ";
	$res = mysqli_query($con,$sql);
	
	while($row = mysqli_fetch_array($res)) {
		$data['userID'] = $row['userID'];
	}

	if (empty($data)) {
		$sql_update = "INSERT INTO subscription (userID, PaymentID, StartDate, DueDate, Price) VALUES('".$userID."','".$PaymentID."','".$StartDate."','".$DueDate."','".$Price."')";
		mysqli_query($con,$sql_update);
	}else{

		$sql_update="UPDATE subscription SET PaymentID='".$PaymentID."',StartDate='".$StartDate."',DueDate='".$DueDate."',Price='259' WHERE userID = '".$userID."'";
		mysqli_query($con,$sql_update);
	}

	mysqli_close($con);
	echo ("<script language='JavaScript'>
		alert('Complete!');
		window.location.href='manage_payment.php';
		</script>"); 
	
}

function getCheckExpiredUser($userID){

	global $con;
	$sql = "SELECT COUNT(*) as numCount FROM subscription WHERE DueDate < NOW() AND userID = '".$userID."'";
	$res = mysqli_query($con,$sql);
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}

function getCheckSubscribe($userID){

	global $con;
	$sql = "SELECT COUNT(*) as numCount FROM subscription WHERE userID = '".$userID."'";
	$res = mysqli_query($con,$sql);
	$result=mysqli_fetch_array($res,MYSQLI_ASSOC);
	return $result;

	mysqli_close($con);

}


function getSearchMovie($search){
	global $con;

	$sql = "SELECT * FROM movie m LEFT JOIN genre g ON m.GenreID = g.GenreID WHERE m.MovieName LIKE '%" . $search . "%' OR g.GenreType LIKE '%" . $search . "%'";
	$res = mysqli_query($con,$sql);
	$data = array();
	while($row = mysqli_fetch_assoc($res)) {
		$namesArray[] = array(
			'MovieID' => $row['MovieID'],
			'GenreType' => $row['GenreType'],
			'MovieName' => $row['MovieName'],
			'GenreID' => $row['GenreID'],
			'MoviePoster' => $row['MoviePoster'],
			'MovieDesc' => $row['MovieDesc'],
			'MovieLength' => $row['MovieLength'],
			'ReleaseDate' => $row['ReleaseDate'],
			'MovieFile' => $row['MovieFile'],
			'TotalViews' => $row['TotalViews']);
	}

	$data = $namesArray;

	return $data;
	mysqli_close($con);

}

?>