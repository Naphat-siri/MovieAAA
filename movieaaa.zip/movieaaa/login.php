﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php 
if(isset($_POST["login"])){
  checkLogin($_POST["Email"],$_POST["Password"]);
}

?>
<body style="background: #70bbb1;">
  <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-5 animate-box" data-animate-effect="fadeInLeft">
            <img class="img-responsive" src="images/login_ico.png" alt="">
          </div>
          <div class="col-md-7 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">Login</h2>

            <form name="register_form" action="" method="post" >
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" name="Email" placeholder="Email">
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" name="Password" placeholder="Password">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12" style="text-align: right;">
                  <div class="form-group">
                    <input type="submit" name="login" class="btn btn-primary btn-outline" value="Login">
                    <a href="register.php" class="btn btn-warning btn-outline">Register</a>
                  </div>
                </div>
              </div>


            </form>

          </div>
        </div>
      </div>

      

    </div>
  </div>


</body>
</html>

