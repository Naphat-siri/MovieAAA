﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php
$currentMovie = getCurrentMovie($_GET["MovieID"]);
$allCategory = getAllCategory();
if(isset($_POST["submit"])){
  if($_POST["MovieID"] == ""){
    saveMovie($_POST["GenreID"],$_POST["MovieName"],$_POST["MovieLength"],$_POST["ReleaseDate"],$_POST["MovieDesc"],$_FILES["MoviePoster"]["name"],$_FILES["MovieFile"]["name"]);
  }else{
    editMovie($_POST["MovieID"],$_POST["GenreID"],$_POST["MovieName"],$_POST["MovieLength"],$_POST["ReleaseDate"],$_POST["MovieDesc"],$_FILES["MoviePoster"]["name"],$_FILES["MovieFile"]["name"]);
  }
}
if($_GET["MovieID"] == ""){
  $txtHead = "Add Movie";
}else{
  $txtHead = "Edit Movie";
}
?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">
    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-5 animate-box" data-animate-effect="fadeInLeft">
            <?php if($currentMovie["MoviePoster"] != ""){ ?>
              <img class="img-responsive" src="images/poster/<?php echo $currentMovie["MoviePoster"];?>" alt="" id="blah">
            <?php }else{ ?>
              <img class="img-responsive" src="images/movie_ico.png" alt="" id="blah">
            <?php } ?>
            
          </div>
          <div class="col-md-7 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading"><?php echo $txtHead;?></h2>

            <form action="" method="post" enctype="multipart/form-data">
              <input type="hidden" class="form-control" name="MovieID" value="<?php echo $currentMovie["MovieID"];?>">

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Genre</label>
                    <select name="GenreID" class="form-control" id="GenreID">
                      <option value="">-- Please Select --</option>
                      <?php foreach($allCategory as $data){ ?>
                        <?php $selected = ""; 
                        if($currentMovie['GenreID'] == $data['GenreID']){
                          $selected = " selected"; 
                        } 
                        ?> 
                        <option value="<?php echo $data['GenreID']?>" <?php echo $selected;?>><?php echo $data['GenreType']?></option>
                      <?php } ?>
                    </select>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Movie's Name</label>
                    <input type="text" class="form-control" name="MovieName" required value="<?php echo $currentMovie["MovieName"];?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Length (Minute)</label>
                    <input type="text" class="form-control" name="MovieLength" required value="<?php echo $currentMovie["MovieLength"];?>">
                  </div>
                </div>
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Release Date</label>
                    <input type="text" class="form-control" name="ReleaseDate" id="ReleaseDate" required value="<?php echo $currentMovie["ReleaseDate"];?>">
                  </div>
                </div>
              </div>
              
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Short Desciption</label>
                    <textarea class="form-control" name="MovieDesc" required><?php echo $currentMovie["MovieDesc"];?></textarea>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Poster</label>
                    <input type="file" class="form-control" name="MoviePoster" id="MoviePoster" placeholder="Movie Poster" >
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Movie's File</label>
                    <input type="file" class="form-control" name="MovieFile" id="MovieFile" placeholder="Movie File" >
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12" style="text-align: right;">
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary btn-outline" value="Submit">
                  </div>
                </div>
              </div>


            </form>

          </div>
        </div>
        
      </div>

      <script type="text/javascript">
        function readURL(input) {
          if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
              $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
          }
        }

        $("#MoviePoster").change(function() {
          readURL(this);
        });
      </script>
      <script>
    
      $('#ReleaseDate').datetimepicker({
        lang:'th',
        timepicker:false,
        format:'d/m/Y'
      });
    </script>
      

    </div>
  </div>


</body>
</html>

