﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php

$allCategory = getAllCategory();
if (isset($_GET['delete'])) {
  deleteCategory($_GET['delete']);
}

?>
<body style="background: #70bbb1;">
  <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">Genre Information</h2>
            <a href="edit_category.php" class="btn btn-success" style="float: right;margin-right: 25px;">add</a>
            <table class="table align-items-left" id="data_table">
              <thead>
                <tr>
                  <th>Genre</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php if(empty($allCategory)){ ?>
                <?php }else{?>
                  <?php foreach($allCategory as $data){ ?>
                    <tr>
                      <td><?php echo $data["GenreType"];?></td>
                      <td style="text-align: right;">
                        <a href="edit_category.php?GenreID=<?php echo $data["GenreID"];?>" class="btn btn-warning">edit</a>
                        <a href="?delete=<?php echo $data['GenreID'];?>" class="btn btn-danger" onClick="javascript: return confirm('Confirm Delete');">Delete</a>
                      </td>
                    </tr>
                  <?php } ?>
                <?php } ?>
              </tbody>
            </table>
            

          </div>
        </div>
      </div>

      

    </div>
  </div>


</body>
</html>

