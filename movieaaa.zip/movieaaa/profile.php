﻿<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>

<?php
$currentUser = getCurrentUser($_SESSION["id"]); 
if(isset($_POST["submit"])){
  editProfile($_POST["userID"],$_POST["Email"],$_POST["Password"],$_POST["FirstName"],$_POST["LastName"],$_FILES["UserPicture"]["name"]);
}

?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-5 animate-box" data-animate-effect="fadeInLeft">
            <?php if($currentUser["UserPicture"] != ""){ ?>
              <img class="img-responsive" src="images/user/<?php echo $currentUser["UserPicture"];?>" alt="" id="blah">
            <?php }else{ ?>
              <img class="img-responsive" src="images/profile_ico.png" alt="" id="blah">
            <?php }?>
          </div>
          <div class="col-md-7 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">Profile</h2>

            <!-- The form tag with enctype attribute added -->
            <form name="register_form" action="" method="post" enctype="multipart/form-data">
              <input type="hidden" class="form-control" name="userID" value="<?php echo $currentUser["userID"];?>">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Username</label>
                    <input type="text" class="form-control" name="Email" placeholder="Email" required value="<?php echo $currentUser["Email"];?>">
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" name="Password" placeholder="Password" required value="<?php echo $currentUser["Password"];?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Name</label>
                    <input type="text" class="form-control" name="FirstName" placeholder="FirstName" required value="<?php echo $currentUser["FirstName"];?>">
                  </div>
                  <div class="form-group">
                    <label>Surname</label>
                    <input type="text" class="form-control" name="LastName" placeholder="LastName" required value="<?php echo $currentUser["LastName"];?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Profile's picture</label>
                    <input type="file" class="form-control" name="UserPicture" id="UserPicture">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12" style="text-align: right;">
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary btn-outline" value="submit">
                  </div>
                </div>
              </div>
            </form>

          </div>
        </div>
        
      </div>
      

    </div>
  </div>


</body>
</html>
