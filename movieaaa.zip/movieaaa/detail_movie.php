﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php
$currentMovie = getCurrentMovie($_GET["MovieID"]);
if(isset($_POST["submit"])){
  saveHistory($_POST["MovieID"],$_POST["UserID"],$_POST["MovieFile"]);
}
?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <h2 class="fh5co-heading animate-box" data-animate-effect="fadeInLeft">Movie Details</h2>
          <div class="col-md-4 animate-box" data-animate-effect="fadeInLeft">
            <?php if($currentMovie["MoviePoster"] != ""){ ?>
              <img class="img-responsive" src="images/poster/<?php echo $currentMovie["MoviePoster"];?>" alt="" id="blah">
            <?php }else{ ?>
              <img class="img-responsive" src="images/register_ico.png" alt="" id="blah">
            <?php } ?>
            
          </div>
          <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">Details</h2>
            <form action="" method="post" enctype="multipart/form-data">
              <input type="hidden" class="form-control" name="MovieID" value="<?php echo $currentMovie["MovieID"];?>">
              <input type="hidden" class="form-control" name="UserID" value="<?php echo $_SESSION["id"];?>">
              <input type="hidden" class="form-control" name="MovieFile" value="<?php echo $currentMovie["MovieFile"];?>">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Movie's Name</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentMovie["MovieName"];?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Genre</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentMovie["GenreType"];?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Length</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentMovie["MovieLength"];?> Minutes</label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Release Date</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo formatDateFull($currentMovie["ReleaseDate"]);?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Short Description</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentMovie["MovieDesc"];?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Total Views</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentMovie["TotalViews"];?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12" style="text-align: center;">
                  <div class="form-group">
                    <?php if($_SESSION["id"] != "" && !empty($_SESSION["id"])){ ?>
                      <?php 
                        $checkExpiredUser = getCheckExpiredUser($_SESSION["id"]);
                        $checkSubscribe = getCheckSubscribe($_SESSION["id"]);
                      ?>
                      <?php if($checkSubscribe["numCount"] != 0){ ?>
                        <?php if($checkExpiredUser["numCount"] == 0){ ?>
                          <input type="submit" name="submit" class="btn btn-primary btn-outline" value="Watch Movie">
                        <?php }else{ ?>
                          <label style="color:red;">Subscription expired</label>
                        <?php } ?>
                      <?php }else{ ?>
                      <label style="color:red;">Subscriber Only</label>
                      <?php } ?>
                      
                      
                    <?php }else{ ?>
                      <label style="color:red;">Please Login</label>
                    <?php } ?>
                  </div>
                </div>
              </div>


            </form>



          </div>

        </div>
       
      </div>


    </div>
  </div>


</body>
</html>

