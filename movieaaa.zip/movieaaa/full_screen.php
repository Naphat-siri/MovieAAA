﻿<!DOCTYPE html>
<html>
<head>
<style>
  body {
    margin: 0;
    padding: 0;
    background-color: #333;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

/* Style the fullscreen button */
#fullscreenBtn {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 9999;
  background-color: #333;
  color: #fff;
  border: none;
  cursor: pointer;
}

/* Style the video */
video {
  width: 100%;
  height: auto;
}
</style>
</head>
<body>

<!-- Add a button to toggle fullscreen mode -->
<button id="fullscreenBtn">FullScreen Mode OFF</button>

<!-- Add a video element From Path File in same Directory -->
<video id="myVideo" controls>
 <source src="images/movie/<?php echo $_GET["files"];?>" type="video/mp4">
</video>
<script>
const fullscreenBtn = document.getElementById('fullscreenBtn');
const body = document.body;
const video = document.getElementById('myVideo');

fullscreenBtn.addEventListener('click', () => {
  if (!document.fullscreenElement) {
    // If no element is in fullscreen, make the body go fullscreen
    if (body.requestFullscreen) {
    body.requestFullscreen();
    } else if (body.mozRequestFullScreen) {
    body.mozRequestFullScreen();
    } else if (body.webkitRequestFullscreen) {
    body.webkitRequestFullscreen();
    } else if (body.msRequestFullscreen) {
    body.msRequestFullscreen();
    }

    //fullscreenBtn.textContent = 'FullScreen Mode ON';
} else {
    // If an element is in fullscreen, exit fullscreen mode
    if (document.exitFullscreen) {
    document.exitFullscreen();
    } else if (document.mozCancelFullScreen) {
    document.mozCancelFullScreen();
    } else if (document.webkitExitFullscreen) {
    document.webkitExitFullscreen();
    } else if (document.msExitFullscreen) {
    document.msExitFullscreen();
    }
    //fullscreenBtn.textContent = 'FullScreen Mode OFF';
  }
});
</script>
</body>
</html>
