﻿<?php 
$user = getUser($_SESSION["id"]);
$categoryList = getAllCategory();
if (isset($_GET['logout'])) {
  logout();
}
?>
<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
<aside id="fh5co-aside" role="complementary" class="border js-fullheight">

  <h1 id="fh5co-logo"><a href="index.php">MovieAAA</a></h1>
  <nav id="fh5co-main-menu" role="navigation">
    <ul>
      <?php if($_SESSION["id"] == "" && empty($_SESSION["id"])){ ?>
        <li class="fh5co-active"><a href="index.php">Home</a></li>
        <?php if(empty($categoryList)){ ?>
        <?php }else{?>
          <?php foreach($categoryList as $dataCate){ ?>
            <li><a href="all_category.php?GenreID=<?php echo $dataCate["GenreID"];?>"><?php echo $dataCate["GenreType"];?></a></li>
          <?php } ?>
        <?php } ?>
        <!---->
        <li><a href="login.php">Login</a></li>
        
      <?php }else{ ?>
        <?php if($_SESSION["role"] == 1){ ?>
          <!--class="fh5co-active"-->
          <li><a href="index.php">Home</a></li>
          <li><a href="manage_admin.php">Admin Information</a></li>
          <li><a href="manage_member.php">Users Information</a></li>
          <li><a href="manage_category.php">Genre Information</a></li>
          <li><a href="manage_movie.php">Movie Information</a></li>
          <!--<li><a href="manage_payment.php">Payment</a></li>-->
          <li><a href="profile.php">Profile</a></li>
          <li><a href="?logout=true">Sign out</a></li>
        <?php } ?>
        <?php if($_SESSION["role"] == 2){ ?>
          <li class="fh5co-active"><a href="index.php">Home</a></li>
          <?php if(empty($categoryList)){ ?>
          <?php }else{?>
            <?php foreach($categoryList as $dataCate){ ?>
              <li><a href="all_category.php?GenreID=<?php echo $dataCate["GenreID"];?>"><?php echo $dataCate["GenreType"];?></a></li>
            <?php } ?>
          <?php } ?>
          <li><a href="manage_payment.php">Payment</a></li>
          <li><a href="profile.php">Profile</a></li>
          <li><a href="?logout=true">Logout</a></li>
        <?php } ?>
      <?php } ?>
      
    </ul>
  </nav>

  <div class="fh5co-footer">
    <p><small><strong>MovieAAA</span> <span>AnyWhere </span> <span>AnyTime</span><span>With AnyOne</span></strong></small></p>
  </div>

</aside>