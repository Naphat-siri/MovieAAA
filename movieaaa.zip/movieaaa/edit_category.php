﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php
$currentCategory = getCurrentCategory($_GET["GenreID"]);
if(isset($_POST["submit"])){
  if($_POST["GenreID"] == ""){
    saveCategory($_POST["GenreType"]);
  }else{
    editCategory($_POST["GenreID"],$_POST["GenreType"]);
  }
}
if($_GET["GenreID"] == ""){
  $txtHead = "Add Genre";
}else{
  $txtHead = "Edit Genre";
}
?>
<body style="background: #70bbb1;">
  <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-5 animate-box" data-animate-effect="fadeInLeft">
            <img class="img-responsive" src="images/category_ico.png" alt="" id="blah">
          </div>
          <div class="col-md-7 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading"><?php echo $txtHead;?></h2>

            <form action="" method="post" enctype="multipart/form-data">
              <input type="hidden" class="form-control" name="GenreID" value="<?php echo $currentCategory["GenreID"];?>">

              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Genre</label>
                    <input type="text" class="form-control" name="GenreType" placeholder="GenreType" required value="<?php echo $currentCategory["GenreType"];?>">
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12" style="text-align: right;">
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary btn-outline" value="Submit">
                  </div>
                </div>
              </div>


            </form>

          </div>
        </div>
        <
      </div>

      <script type="text/javascript">
        function readURL(input) {
          if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
              $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
          }
        }

        $("#cate_img").change(function() {
          readURL(this);
        });
      </script>
      

    </div>
  </div>


</body>
</html>

