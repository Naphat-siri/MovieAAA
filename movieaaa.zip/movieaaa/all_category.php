﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php

$currentCategory = getCurrentCategory($_GET["GenreID"]);
$allMovieInCategory = getAllMovieInCategory($_GET["GenreID"]);
if(isset($_POST["submit"])){

  $allMovieInCategory = getSearchMovie($_POST["search"]);
  
}
?>

<body style="background: #70bbb1;">
  <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <h2 class="fh5co-heading animate-box" data-animate-effect="fadeInLeft"><?php echo $currentCategory["GenreType"];?></h2>
        <form action="" method="post">
          <table style="width:100%">
            <tr>
              <td>
                <input type="text" name="search" id="search" class="form-control border-input" placeholder="Search Movie">
              </td>
              <td style="text-align: center;">
                <input type="submit" name="submit" class="btn btn-primary btn-outline" value="Search">
              </td>
            </tr>
          </table>
        </form>
        <br/>
        <div class="row row-bottom-padded-md">
          <?php if(empty($allMovieInCategory)){ ?>
          <?php }else{?>
            <?php foreach($allMovieInCategory as $data){ ?>
              <div class="col-md-3 col-sm-6 col-padding animate-box" data-animate-effect="fadeInLeft">
                <div class="blog-entry">
                  <a href="detail_movie.php?MovieID=<?php echo $data['MovieID']?>" class="blog-img"><img src="images/poster/<?php echo $data['MoviePoster'];?>" class="img-responsive"></a>
                  <div class="desc">
                    <h3><a href="detail_movie.php?MovieID=<?php echo $data['MovieID']?>"><?php echo $data["MovieName"];?></a></h3>
                    <a href="detail_movie.php?MovieID=<?php echo $data['MovieID']?>" class="lead">Watch Movie <i class="icon-video"></i></a>
                  </div>
                </div>
              </div>
            <?php } ?>
          <?php } ?>


        </div>
      </div>

      

    </div>
  </div>


</body>
</html>

