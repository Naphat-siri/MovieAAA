﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php 
$allMovie = getAllMovie();
if (isset($_GET['delete'])) {
  deleteMovie($_GET['delete']);
}

?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">Movie Information</h2>
            <a href="edit_movie.php" class="btn btn-success" style="float: right;margin-right: 25px;">add</a>
            <table class="table align-items-left" id="data_table">
              <thead>
                <tr>
                  <th>Movie's name</th>
                  <th>Genre</th>
                  <th>Length</th>
                  <th>Release Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php if(empty($allMovie)){ ?>
                <?php }else{?>
                  <?php foreach($allMovie as $data){ ?>
                    <tr>
                      <td><?php echo $data["MovieName"];?></td>
                      <td><?php echo $data["GenreType"];?></td>
                      <td><?php echo $data["MovieLength"];?></td>
                      <td><?php echo formatDateFull($data["ReleaseDate"]);?></td>
                      <td style="text-align: right;">
                        <a href="edit_movie.php?MovieID=<?php echo $data["MovieID"];?>" class="btn btn-warning">edit</a>
                        <a href="?delete=<?php echo $data['MovieID'];?>" class="btn btn-danger" onClick="javascript: return confirm('Confirm Delete');">Delete</a>
                      </td>
                    </tr>
                  <?php } ?>
                <?php } ?>
              </tbody>
            </table>
            

          </div>
        </div>
      </div>

      

    </div>
  </div>


</body>
</html>

