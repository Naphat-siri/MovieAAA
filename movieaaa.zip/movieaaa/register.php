﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php 
if(isset($_POST["submit"])){
  saveRegister($_POST["Email"],$_POST["Password"],$_POST["FirstName"],$_POST["LastName"],$_FILES["UserPicture"]["name"]);
}

?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-5 animate-box" data-animate-effect="fadeInLeft">
            <img class="img-responsive" src="images/profile_ico.png" alt="" id="blah">
          </div>
          <div class="col-md-7 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">Register</h2>

            <form name="register_form" action="" method="post" enctype="multipart/form-data">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Email</label>
                    <input type="text" class="form-control" name="Email" placeholder="Email" required>
                  </div>
                  <div class="form-group">
                    <label>Password</label>
                    <input type="password" class="form-control" name="Password" placeholder="Password" required>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Name</label>
                    <input type="text" class="form-control" name="FirstName" placeholder="First Name" required>
                  </div>
                  <div class="form-group">
                    <label>Surname</label>
                    <input type="text" class="form-control" name="LastName" placeholder="Last Name" required>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Profile Picture</label>
                    <input type="file" class="form-control" name="UserPicture" id="UserPicture" placeholder="Profile Picture" >
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12" style="text-align: right;">
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary btn-outline" value="Register">
                  </div>
                </div>
              </div>


            </form>

          </div>
        </div>
        
        <script type="text/javascript">
        function readURL(input) {
          if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function(e) {
              $('#blah').attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
          }
        }

        $("#UserPicture").change(function() {
          readURL(this);
        });
      </script>
      </div>
      

    </div>
  </div>


</body>
</html>

