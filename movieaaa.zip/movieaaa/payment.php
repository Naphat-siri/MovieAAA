﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php
$currentPayment = getCurrentPayment($_GET["PaymentID"]);
$currentMember = getCurrentMember($currentPayment["userID"]);
$dateNow = date("Y-m-d");
$dt = strtotime($dateNow);
$expDate =  date("Y-m-d", strtotime("+1 month", $dt));
if(isset($_POST["submit"])){
  confirmPayment($_POST["userID"],$_POST["PaymentID"],$_POST["StartDate"],$_POST["DueDate"],$_POST["Price"]);
}

?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <h2 class="fh5co-heading animate-box" data-animate-effect="fadeInLeft">pay</h2>
          <div class="col-md-4 animate-box" data-animate-effect="fadeInLeft">
            <img class="img-responsive" src="images/payment_ico.png" alt="" id="blah">
          </div>
          <div class="col-md-8 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">Details</h2> 
            <form action="" method="post" enctype="multipart/form-data">
              <input type="hidden" class="form-control" name="userID" value="<?php echo $_SESSION["id"];?>">
              <input type="hidden" class="form-control" name="PaymentID" value="<?php echo $currentPayment["PaymentID"];?>">
              <input type="hidden" class="form-control" name="Price" value="259">
              <input type="hidden" class="form-control" name="StartDate" value="<?php echo $dateNow;?>">
              <input type="hidden" class="form-control" name="DueDate" value="<?php echo $expDate;?>">
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Name-Surname</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentMember["FirstName"];?> <?php echo $currentMember["LastName"];?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Email</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentMember["Email"];?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Credit Card Number</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentPayment["CreditCardnum"];?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>CVV</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo $currentPayment["CVV"];?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Expiry Date</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo formatDateFull($currentPayment["expiryDate"]);?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Subscription expired date</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label><?php echo formatDateFullConvertYear($expDate);?></label>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-3">
                  <div class="form-group">
                    <label>Price</label>
                  </div>
                </div>
                <div class="col-md-9">
                  <div class="form-group">
                    <label>259 Baht / Month</label>
                  </div>
                </div>
              </div>
              
              <div class="row">
                <div class="col-md-12" style="text-align: center;">
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary btn-outline" value="pay">
                  </div>
                </div>
              </div>


            </form>



          </div>

        </div>
        
      </div>


    </div>
  </div>


</body>
</html>

