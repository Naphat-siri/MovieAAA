﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php
$allPayment = getAllPayment($_SESSION["id"]);
if (isset($_GET['delete'])) {
  deletePayment($_GET['delete']);
}

?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">Payment Information</h2>
            <a href="edit_payment.php" class="btn btn-success" style="float: right;margin-right: 25px;">add payment</a>
            <table class="table align-items-left" id="data_table">
              <thead>
                <tr>
                  <th>Card holder's name</th>
                  <th>Credit Card Number</th>
                  <th>Expiry Date</th>
                  <th>Type</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php if(empty($allPayment)){ ?>
                <?php }else{?>
                  <?php foreach($allPayment as $data){ ?>
                    <tr>
                      <td><?php echo $data["CardHolderName"];?></td>
                      <td><?php echo $data["CreditCardnum"];?></td>
                      <td><?php echo formatDateFull($data["expiryDate"]);?></td>
                      <td><?php echo $data["CardType"];?></td>
                      <td style="text-align: right;">
                        <a href="payment.php?PaymentID=<?php echo $data["PaymentID"];?>" class="btn btn-info">Use this payment</a>
                        <a href="edit_payment.php?PaymentID=<?php echo $data["PaymentID"];?>" class="btn btn-warning">edit</a>
                        <a href="?delete=<?php echo $data['PaymentID'];?>" class="btn btn-danger" onClick="javascript: return confirm('Confirm Delete');">Delete</a>
                      </td>
                    </tr>
                  <?php } ?>
                <?php } ?>
              </tbody>
            </table>
            

          </div>
        </div>
      </div>

      

    </div>
  </div>


</body>
</html>

