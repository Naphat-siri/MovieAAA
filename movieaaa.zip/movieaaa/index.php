﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");

?>
<?php 
$allMovieTopView = getAllMovieTopView();
$newMovieTopView = getNewMovieTopView();
$allCategoryIndex = getAllCategory();
?>
<body style="background: #70bbb1;"> 
  <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <aside id="fh5co-hero" class="js-fullheight">
        <div class="flexslider js-fullheight">
          <ul class="slides">
            <li style="background-image: url(images/backg.png);">
              <div class="overlay"></div>
              <div class="container-fluid">
                <div class="row">
                  <div class="col-md-8 col-md-offset-2 text-center js-fullheight slider-text">
                    <div class="slider-text-inner">
                      <h1>Welcome to MovieAAA</h1>
                      <h2>Anywhere Anytime with Anyone</h2>
                      
                    </div>
                  </div>
                </div>
              </div>
            </li>
            
          </ul>
        </div>
      </aside>
      

      <div class="fh5co-narrow-content">
        <h2 class="fh5co-heading animate-box" data-animate-effect="fadeInLeft">New upload</h2>
        <div class="row row-bottom-padded-md">
          <?php if(empty($newMovieTopView)){ ?>
          <?php }else{?>
            <?php foreach($newMovieTopView as $dataRan){ ?>
              <div class="col-md-3 col-sm-6 col-padding animate-box" data-animate-effect="fadeInLeft">
                <div class="blog-entry">
                  <a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>" class="blog-img"><img src="images/poster/<?php echo $dataRan['MoviePoster']?>" class="img-responsive" ></a>
                  <div class="desc">
                    <h3><a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>"><?php echo $dataRan['MovieName']?></a></h3>
                    <span><strong><?php echo $dataRan['GenreType']?> </strong></span>
                    <p><?php echo $dataRan['MovieLength']?> / Minute</p>
                    <a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>" class="lead">Watch Movies <i class="icon-video"></i></a>
                  </div>
                </div>
              </div>
            <?php } ?>
          <?php } ?>

        </div>
        
        <div class="fh5co-narrow-content">
        <h2 class="fh5co-heading animate-box" data-animate-effect="fadeInLeft">Most Watched</h2>
        <div class="row row-bottom-padded-md">
          <?php if(empty($allMovieTopView)){ ?>
          <?php }else{?>
            <?php foreach($allMovieTopView as $dataRan){ ?>
              <div class="col-md-3 col-sm-6 col-padding animate-box" data-animate-effect="fadeInLeft">
                <div class="blog-entry">
                  <a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>" class="blog-img"><img src="images/poster/<?php echo $dataRan['MoviePoster']?>" class="img-responsive" ></a>
                  <div class="desc">
                    <h3><a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>"><?php echo $dataRan['MovieName']?></a></h3>
                    <span><strong><?php echo $dataRan['GenreType']?> </strong></span>
                    <p><?php echo $dataRan['MovieLength']?> / Minute</p>
                    <a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>" class="lead">Watch Movies <i class="icon-video"></i></a>
                  </div>
                </div>
              </div>
            <?php } ?>
          <?php } ?>

        </div>      

      </div>
      <?php if(empty($allCategoryIndex)){ ?>
      <?php }else{?>
        <?php foreach($allCategoryIndex as $dataCate){ ?>
          
          <?php $currentCategoryLimit = getCurrentCategory($dataCate["GenreID"]);?>
          <?php $allMovieInCategoryLimit = getAllMovieInCategoryLimit($dataCate["GenreID"]);?>
          <div class="fh5co-narrow-content">

            <h2 class="fh5co-heading animate-box" data-animate-effect="fadeInLeft"><?php echo $currentCategoryLimit["GenreType"];?></h2>
            <div class="row row-bottom-padded-md">
              <?php if(empty($allMovieInCategoryLimit)){ ?>
              <?php }else{?>
                <?php foreach($allMovieInCategoryLimit as $dataRan){ ?>
                  <div class="col-md-3 col-sm-6 col-padding animate-box" data-animate-effect="fadeInLeft">
                    <div class="blog-entry">
                      <a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>" class="blog-img"><img src="images/poster/<?php echo $dataRan['MoviePoster']?>" class="img-responsive" ></a>
                      <div class="desc">
                        <h3><a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>"><?php echo $dataRan['MovieName']?></a></h3>
                        <span><strong><?php echo $dataRan['GenreType']?> </strong></span>
                        <p><?php echo $dataRan['MovieLength']?> / Minute</p>
                        <a href="detail_movie.php?MovieID=<?php echo $dataRan['MovieID']?>" class="lead">Watch Movies <i class="icon-video"></i></a>
                      </div>
                    </div>
                  </div>
                <?php } ?>
              <?php } ?>

            </div>
          </div>
        <?php } ?>
      <?php } ?>

      <div id="get-in-touch">
        <div class="fh5co-narrow-content">
          <div class="row">
            <div class="col-md-4 animate-box" data-animate-effect="fadeInLeft">
              <h1 class="fh5co-heading-colored">MovieAAA</h1>
              <p class="fh5co-lead">Movie Website</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


</body>
</html>

