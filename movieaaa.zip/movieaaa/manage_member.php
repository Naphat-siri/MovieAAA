﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php
$allMember = getAllMember();
if (isset($_GET['delete'])) {
  deleteMember($_GET['delete']);
}

?>
<body style="background: #70bbb1;">
  <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading">User Information</h2>
            <a href="edit_member.php" class="btn btn-success" style="float: right;margin-right: 25px;">add</a>
            <table class="table align-items-left" id="data_table">
              <thead>
                <tr>
                  <th>Name-Surname</th>
                  <th>Email</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php if(empty($allMember)){ ?>
                <?php }else{?>
                  <?php foreach($allMember as $data){ ?>
                    <tr>
                      <td><?php echo $data["FirstName"];?> <?php echo $data["LastName"];?></td>
                      <td><?php echo $data["Email"];?></td>
                      <td style="text-align: right;">
                        <a href="edit_member.php?userid=<?php echo $data["userID"];?>" class="btn btn-warning">edit</a>
                        <a href="?delete=<?php echo $data['userID'];?>" class="btn btn-danger" onClick="javascript: return confirm('Confirm Delete');">Delete</a>
                      </td>
                    </tr>
                  <?php } ?>
                <?php } ?>
              </tbody>
            </table>
            

          </div>
        </div>
      </div>

      

    </div>
  </div>


</body>
</html>

