﻿
<!DOCTYPE html>
<html class="no-js">
<?php
require_once("header.php");
?>
<?php
$currentPayment = getCurrentPayment($_GET["PaymentID"]);

if(isset($_POST["submit"])){
  if($_POST["PaymentID"] == ""){
    savePayment($_POST["userID"],$_POST["CardHolderName"],$_POST["CreditCardnum"],$_POST["expiryDate"],$_POST["CVV"],$_POST["CardType"]);
  }else{
    editPayment($_POST["PaymentID"],$_POST["userID"],$_POST["CardHolderName"],$_POST["CreditCardnum"],$_POST["expiryDate"],$_POST["CVV"],$_POST["CardType"]);
  }
}
if($_GET["PaymentID"] == ""){
  $txtHead = "Add Credit Card";
}else{
  $txtHead = "แEdit Credit Card";
}
?>
<body style="background: #70bbb1;">
 <div id="fh5co-page" style="margin-top: -25px;">

    <?php
    require_once("side_bar.php");
    ?>
    <div id="fh5co-main">
      <div class="fh5co-narrow-content">
        <div class="row row-bottom-padded-md">
          <div class="col-md-5 animate-box" data-animate-effect="fadeInLeft">
            <img class="img-responsive" src="images/payment_ico.png" alt="" id="blah">
          </div>
          <div class="col-md-7 animate-box" data-animate-effect="fadeInLeft">
            <h2 class="fh5co-heading"><?php echo $txtHead;?></h2>

            <form name="register_form" action="" method="post" enctype="multipart/form-data">
              <input type="hidden" class="form-control" name="PaymentID" value="<?php echo $currentPayment["PaymentID"];?>">
              <input type="hidden" class="form-control" name="userID" value="<?php echo $_SESSION["id"];?>">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Card holder's name</label>
                    <input type="text" class="form-control" name="CardHolderName" required value="<?php echo $currentPayment["CardHolderName"];?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Credit Card Number</label>
                    <input type="text" class="form-control" name="CreditCardnum" required value="<?php echo $currentPayment["CreditCardnum"];?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Expiry Date</label>
                    <input type="text" class="form-control" name="expiryDate" id="expiryDate" required value="<?php echo formatDateFull($currentPayment["expiryDate"]);?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>CVV</label>
                    <input type="text" class="form-control" name="CVV" required value="<?php echo $currentPayment["CVV"];?>">
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Type</label>
                    <input type="text" class="form-control" name="CardType" required value="<?php echo $currentPayment["CardType"];?>">
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12" style="text-align: right;">
                  <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary btn-outline" value="Save">
                  </div>
                </div>
              </div>


            </form>

          </div>
        </div>
        

        <script>
          var today = new Date();

          $('#expiryDate').datetimepicker({
            lang:'th',
            minDate:today,
            timepicker:false,
            format:'d/m/Y'
          });
        </script>
      </div>
      

    </div>
  </div>


</body>
</html>

